"""Original, service-complete copy for the About page."""

from html import escape


SERVICE_DETAILS = {
    "car-towing": "For car towing in Dubai, tell us whether the vehicle starts, rolls and steers, where it is waiting and which garage, home or other destination should receive it. We discuss a suitable collection and transport plan after checking access at both ends, availability and the quote.",
    "flatbed-towing": "A flatbed carries a vehicle on a platform when the planned move or vehicle condition calls for that method. Give us the model, wheel condition, clearance, parking level and loading space. The team must confirm that the truck, loading approach and securing arrangement fit the actual car and site.",
    "luxury-car-transport": "Luxury and sports car transport needs attention to low bodywork, long overhangs, modifications and the receiving location. Share the model, any manufacturer transport instructions and photos taken safely. We discuss handling requirements and suitable equipment before accepting a premium vehicle movement.",
    "motorcycle-towing": "Motorcycle towing and transport need a plan for the particular bike, not an assumption based on car equipment. Tell us the make and model, whether it rolls and stands, any accident damage or attached luggage, and where it can be loaded and delivered. A suitable securing arrangement must be confirmed.",
    "emergency-recovery": "A breakdown can leave a car unable or unsafe to continue. For breakdown recovery, give us a checked location pin, nearby landmark, symptoms, wheel mobility and destination. If people or traffic are at risk, follow the relevant emergency or authority instructions first; commercial recovery can be arranged when the scene is safe.",
    "accident-recovery": "Accident recovery concerns a vehicle damaged in a collision and ready for authorised collection. Tell us about visible wheel, steering, suspension or body damage and any fluid leak, along with the release status and receiving workshop. We assess whether the available loading and transport method suits that condition.",
    "desert-recovery": "Desert and off-road recovery depends on terrain, access, vehicle condition and a reliable location. Share a map pin, nearest usable track, whether the vehicle is stuck, tilted or damaged, and whether anyone is in danger. The team must assess whether it can reach the site safely and what method is suitable.",
    "truck-recovery": "Commercial vehicle recovery requires the vehicle type, dimensions, approximate loaded weight, cargo status, wheel condition and access at pickup and destination. Some heavy or specialised vehicles may exceed available equipment or permissions. We assess capacity and scope before confirming a job.",
    "roadside-assistance": "Roadside assistance begins with the problem rather than a guessed repair. Describe what the vehicle did, any warning lights, the exact safe pickup point and whether it can be driven. The team can discuss available help at the vehicle or transport to a workshop; an on-site repair is never assumed.",
    "battery-assistance": "For a possible flat battery or non-starting vehicle, report what happens when you try to start it, the model and whether it is hybrid or electric. Battery boost assistance is discussed only when suitable for the car and location. A successful start may still require workshop diagnosis.",
    "tyre-assistance": "For a flat or damaged tyre, identify the affected wheel, whether a usable spare and locking-wheel-nut key are available, and whether the vehicle is safely parked. The team can discuss tyre help or recovery if the wheel or access makes roadside work unsuitable. Do not drive on a tyre that may be unsafe.",
    "fuel-delivery": "If your vehicle may have run out of fuel, give us the correct fuel type, model and precise location before asking about emergency fuel assistance. We confirm whether the requested help is available and appropriate. If the car has another fault, roadside assessment or towing may be a better next step.",
    "passing-assistance": "If a vehicle must be transported to or from a passing-related appointment, tell us the facility, booked time, vehicle condition, unloading point and whether a return trip is needed. We discuss the transport portion only; the official inspection, paperwork and result remain with the relevant authority and owner.",
}

GROUPS = (
    ("Vehicle towing and transport", ("car-towing", "flatbed-towing", "luxury-car-transport", "motorcycle-towing")),
    ("Recovery after a problem", ("emergency-recovery", "accident-recovery", "desert-recovery", "truck-recovery")),
    ("Roadside and appointment assistance", ("roadside-assistance", "battery-assistance", "tyre-assistance", "fuel-delivery", "passing-assistance")),
)


def render_about(business, services, page_head, contact_panel):
    names = {service_id: name for service_id, name, _, _ in services}
    assert set(SERVICE_DETAILS) == set(names), "About page must cover every service"
    assert {service_id for _, ids in GROUPS for service_id in ids} == set(names)

    sections = []
    for group, ids in GROUPS:
        items = "".join(
            '<div class="about-service-item"><h3><a href="/services/'
            + service_id
            + '/">'
            + escape(names[service_id])
            + '</a></h3><p>'
            + escape(SERVICE_DETAILS[service_id])
            + '</p></div>'
            for service_id in ids
        )
        sections.append('<section class="about-service-group"><h2>' + escape(group) + '</h2>' + items + '</section>')

    phone = escape(business["phone"], quote=True)
    phone_display = escape(business["phoneDisplay"])
    whatsapp = escape(business["whatsapp"], quote=True)
    email = escape(business["email"], quote=True)
    return page_head(
        "ABOUT US",
        "Dubai car recovery, with a clear plan for every vehicle.",
        "Explore our towing, recovery, roadside and motorcycle services across Dubai.",
    ) + f'''<section class="wrap prose about-page">
<h2>About Dubai Car Recovery</h2>
<p><a href="/">Dubai Car Recovery</a> is a direct starting point for drivers and riders who need car towing, vehicle recovery, motorcycle transport or roadside assistance in Dubai. Our website brings the services together so you can describe your actual vehicle and location, find the relevant service page and contact the team without guessing which type of truck or help you need.</p>
<p>We want to be a top choice for customers who value a careful, well-explained service. Our modern website, detailed service guidance and direct Call and WhatsApp options aim to make the first step clearer than a generic towing listing. We believe this practical approach can make us a better fit for many Dubai drivers; the right provider for a particular job still depends on its vehicle, location, equipment and availability.</p>
{''.join(sections)}
<h2>Response time and availability</h2>
<p>We welcome assistance enquiries day or night. We aim to respond promptly, but we do not publish a fixed response or arrival time in minutes. The team can give an estimated arrival only after checking your precise pickup location, the vehicle's condition, access, current availability and the equipment needed. Dubai traffic, a basement entrance, an accident scene or a remote desert location can change the timing. A WhatsApp draft or missed call is not a confirmed dispatch; wait for the team to accept the job and its timing.</p>
<h2>Why customers start with us</h2>
<p>Our ambition is to provide one of Dubai's best-informed towing and recovery experiences: clear questions before collection, care with the vehicle, a suitable transport discussion and an agreed destination. We ask about details that can be easy to miss, such as locked wheels, a low bumper, a motorcycle's balance, a truck's loaded weight or the height of a car-park entrance. These details help us explain what we can actually offer instead of making the same promise for every job.</p>
<h2>Start your enquiry</h2>
<p>Our stated local area is Al Quoz Industrial Area, and we discuss suitable requests across Dubai. Use the <a href="/services/">full services directory</a> to compare categories, or go straight to the <a href="/book/">booking form</a> with the vehicle, pickup point and destination. Call <a href="tel:{phone}">{phone_display}</a>, message the same number on <a href="https://wa.me/{whatsapp}">WhatsApp</a>, or email <a href="mailto:{email}">{email}</a>. Coverage, suitability, arrival estimate and the final quote are confirmed for each request.</p>
{contact_panel()}</section>'''
