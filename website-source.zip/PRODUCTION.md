# Public deployment preparation

The normal build is a local preview and deliberately uses `noindex,nofollow` and a disallowing robots.txt.

For a public client website, build against its actual HTTPS domain:

```sh
python3 source/build.py --production --domain https://www.dubaicarrecovery.site
```

The canonical production host is `www.dubaicarrecovery.site`. Production mode creates canonical URLs, indexable pages and a sitemap derived from the published routes, and allows crawlers in robots.txt. Publish the `dist/` directory on HTTPS hosting and verify all routes on the public domain before using it as a Google Ads destination or applying for AdSense.

The site itself has no CAPTCHA, bot challenge, tracking scripts or forced redirects. Calling uses `tel:+971501263137`; WhatsApp uses `https://wa.me/971501263137`. Native calling/WhatsApp app handling depends on the visitor's device. Location access requires browser permission and HTTPS; it shares a current-location snapshot, not continuous live tracking. Booking requests are sent by the customer in WhatsApp and confirmed by the business.

Use compression and cache static media on the selected public host. Styles/scripts have content-version query parameters so updated files are revalidated correctly. Keep the phone number, public domain and business claims accurate. Google Ads/AdSense approval and search position are determined by Google and are not guaranteed by this implementation.

Official references:
- https://support.google.com/adspolicy/answer/6368661
- https://support.google.com/adsense/answer/7299563

Blog articles are available at /blogs/ and use unique descriptions, canonical URLs and BlogPosting structured data in production mode. The build creates .gz text sidecars; configure the production host to negotiate these files or enable its own gzip/Brotli compression. Versioned CSS/JS may use immutable caching; HTML should be revalidated. The local server provides compression and caching as a preview of this behaviour.
