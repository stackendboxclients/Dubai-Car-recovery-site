"""Package the published site and source for the existing Vercel workflow.

Unpublished blog drafts stay out of the public archive. Recovery illustrations
are stored once in dist/media/recovery and restored by build-production.mjs.
"""
from pathlib import Path
import hashlib
import json
import re
import zipfile

root = Path(__file__).resolve().parent.parent
metadata = json.loads((root / 'source/blogs/metadata.json').read_text())
published = {item['slug'] for item in metadata}
archive_path = root / 'website-source.zip'

with zipfile.ZipFile(archive_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for top in ('PRODUCTION.md', 'source', 'dist', 'scripts'):
        base = root / top
        paths = [base] if base.is_file() else sorted(base.rglob('*'))
        for path in paths:
            if not path.is_file() or path.suffix == '.pyc' or '__pycache__' in path.parts:
                continue
            relative = path.relative_to(root)
            if relative.parts[:3] == ('source', 'assets', 'recovery'):
                continue
            if relative.parts[:2] == ('source', 'blogs') and relative.suffix == '.md' and relative.stem not in published:
                continue
            archive.write(path, relative.as_posix())

digest = hashlib.sha256(archive_path.read_bytes()).hexdigest()
build = root / 'build-production.mjs'
text = build.read_text()
updated, count = re.subn(r"digest\('hex'\)!=='[0-9a-f]{64}'", f"digest('hex')!=='{digest}'", text)
if count != 1:
    raise RuntimeError('Could not locate exactly one archive checksum')
build.write_text(updated)
print(f'Packaged {archive_path.stat().st_size:,} bytes; SHA-256 {digest}')
