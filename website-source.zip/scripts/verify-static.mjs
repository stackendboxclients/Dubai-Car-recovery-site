import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
const root=path.resolve('dist');
const files=[];
function walk(dir){for(const item of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,item.name);if(item.isDirectory())walk(p);else files.push(p);}}
walk(root);
const pages=files.filter(p=>path.basename(p)==='index.html');
assert(pages.length>=28,'Missing generated page');
const titles=new Set();
const canonicalUrls=new Set();
for(const p of pages){
 const html=fs.readFileSync(p,'utf8');
 assert(!html.includes('noindex'),'Preview pages must not be deployed');
 assert(html.includes('https://www.dubaicarrecovery.site/'),'Production canonical missing');
 assert(!html.includes('+971552031145')&&!html.includes('971552031145'),'Retired number found');
 assert(html.includes('tel:+971501263137'),'Call target missing');
 assert(html.includes('https://wa.me/971501263137'),'WhatsApp target missing');
 assert(html.includes('dubaicarrecoverhelp@gmail.com'),'Email missing');
 const title=html.match(/<title>([^<]+)<\/title>/)?.[1];
 const canonical=html.match(/<link rel="canonical" href="([^"]+)"/ )?.[1];
 assert(title&&!titles.has(title),`Missing or duplicate title: ${p}`);titles.add(title);
 assert(canonical&&!canonicalUrls.has(canonical),`Missing or duplicate canonical: ${p}`);canonicalUrls.add(canonical);
 assert.equal((html.match(/<h1\b/g)||[]).length,1,`Expected one H1 in ${p}`);
 assert(html.includes('<meta name="description"'),'Meta description missing');
 const data=html.match(/<script type="application\/ld\+json">([^<]+)<\/script>/)?.[1];
 assert(data,`Structured data missing in ${p}`);JSON.parse(data);
 for(const match of html.matchAll(/(?:href|src)="(\/[^"#?]*)(?:[?#][^"]*)?"/g)){
  const pathname=decodeURIComponent(match[1]);
  const target=path.join(root,pathname);
  assert(fs.existsSync(target),`Missing local target ${pathname} in ${p}`);
  if(fs.statSync(target).isDirectory())assert(fs.existsSync(path.join(target,'index.html')),`Missing index ${pathname}`);
 }
}
assert(fs.readFileSync(path.join(root,'robots.txt'),'utf8').includes('Allow: /'));
const sitemap=fs.readFileSync(path.join(root,'sitemap.xml'),'utf8');
assert.equal((sitemap.match(/<url>/g)||[]).length,pages.length);
for(const url of canonicalUrls)assert(sitemap.includes(`<loc>${url}</loc>`),`Canonical missing from sitemap: ${url}`);
console.log(`Production static output verified: ${pages.length} pages, unique metadata, contact links, JSON-LD, sitemap and local assets.`);
