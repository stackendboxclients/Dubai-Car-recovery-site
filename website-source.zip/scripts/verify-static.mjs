import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
const root=path.resolve('dist');
const files=[];
function walk(dir){for(const item of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,item.name);if(item.isDirectory())walk(p);else files.push(p);}}
walk(root);
const pages=files.filter(p=>path.basename(p)==='index.html');
assert.equal(pages.length,24,'Missing generated page');
for(const p of pages){
 const html=fs.readFileSync(p,'utf8');
 assert(!html.includes('noindex'),'Preview pages must not be deployed');
 assert(html.includes('https://www.dubaicarrecovery.site/'),'Production canonical missing');
 for(const match of html.matchAll(/(?:href|src)="(\/[^"#?]*)(?:[?#][^"]*)?"/g)){
  const pathname=decodeURIComponent(match[1]);
  const target=path.join(root,pathname);
  assert(fs.existsSync(target),`Missing local target ${pathname} in ${p}`);
  if(fs.statSync(target).isDirectory())assert(fs.existsSync(path.join(target,'index.html')),`Missing index ${pathname}`);
 }
}
assert(fs.readFileSync(path.join(root,'robots.txt'),'utf8').includes('Allow: /'));
assert.equal((fs.readFileSync(path.join(root,'sitemap.xml'),'utf8').match(/<url>/g)||[]).length,24);
console.log('Production static output verified: 24 pages, indexing, canonical URLs and local assets.');
