"""Render the approved hero still as a restrained, seamless 2.5D motion loop.

This keeps the approved photographic background and vehicle identity. It does not
create or substitute 3D vehicle models. Pillow and NumPy are the only runtime
dependencies; FFmpeg performs final video encoding separately.
"""
from __future__ import annotations

from pathlib import Path
import argparse
import math

import numpy as np
from PIL import Image, ImageDraw, ImageEnhance, ImageFilter

ROOT = Path(__file__).resolve().parent.parent
SOURCE = ROOT / "source" / "hero-source"


def cover(image: Image.Image, size: tuple[int, int], focus_x: float = .5) -> Image.Image:
    scale = max(size[0] / image.width, size[1] / image.height)
    resized = image.resize((round(image.width * scale), round(image.height * scale)), Image.Resampling.LANCZOS)
    left = round((resized.width - size[0]) * focus_x)
    top = (resized.height - size[1]) // 2
    return resized.crop((left, top, left + size[0], top + size[1]))


def motion_streaks(size: tuple[int, int], phase: float, mobile: bool) -> Image.Image:
    w, h = size
    layer = Image.new("RGBA", size)
    draw = ImageDraw.Draw(layer)
    road_top = int(h * (.54 if mobile else .60))
    speed = w * (1.0 if mobile else 1.35)
    for i in range(12):
        x = int((i * w / 7 - phase * speed) % (w + 220)) - 110
        y = road_top + int(((i * 73) % max(1, h - road_top)) * .9)
        length = 75 + (i % 4) * 45
        color = (255, 245, 230, 18 if i % 3 else 28)
        draw.line((x, y, x + length, y + 2), fill=color, width=max(1, h // 360))
    return layer.filter(ImageFilter.GaussianBlur(max(2, w // 420)))


def make_frame(background: Image.Image, vehicle_source: Image.Image, size: tuple[int, int], frame: int, total: int, mobile: bool) -> Image.Image:
    phase = frame / total
    drift = math.sin(phase * math.tau)
    zoom = 1.018 + .004 * math.sin(phase * math.tau)

    bg = cover(background, (round(size[0] * zoom), round(size[1] * zoom)), .56 if mobile else .5)
    bx = (bg.width - size[0]) // 2 + round(drift * (3 if mobile else 5))
    by = (bg.height - size[1]) // 2 + round(math.sin(phase * math.tau + .6) * 2)
    frame_image = bg.crop((bx, by, bx + size[0], by + size[1])).convert("RGBA")
    frame_image = Image.alpha_composite(frame_image, motion_streaks(size, phase, mobile))

    # Keep the approved wheels intact. The former rotating crop treatment was
    # visibly artificial; road/light movement now supplies the speed cue.
    vehicle = vehicle_source.copy()
    if mobile:
        target_w = round(size[0] * .99)
        target_h = round(vehicle.height * target_w / vehicle.width)
        vehicle = vehicle.resize((target_w, target_h), Image.Resampling.LANCZOS)
        x = round((size[0] - target_w) / 2 + drift * 7)
        y = round(size[1] * .59 + math.sin(phase * math.tau + .4) * 1.5)
    else:
        target_w = round(size[0] * .70)
        target_h = round(vehicle.height * target_w / vehicle.width)
        vehicle = vehicle.resize((target_w, target_h), Image.Resampling.LANCZOS)
        x = round(size[0] * .25 + drift * 9)
        y = round(size[1] * .20 + math.sin(phase * math.tau + .4) * 1.5)

    shadow = Image.new("RGBA", size)
    sd = ImageDraw.Draw(shadow)
    sd.ellipse((x + target_w * .08, y + target_h * .86, x + target_w * .96, y + target_h * 1.01), fill=(0, 0, 0, 115))
    shadow = shadow.filter(ImageFilter.GaussianBlur(max(9, size[0] // 90)))
    frame_image = Image.alpha_composite(frame_image, shadow)
    frame_image.alpha_composite(vehicle, (x, y))
    # Do not sweep artificial light across the vehicle. The approved paint and
    # city reflections remain unchanged and readable.

    if mobile:
        shade = Image.new("RGBA", size)
        shade_alpha = Image.new("L", size)
        a = np.zeros((size[1], size[0]), dtype=np.uint8)
        stop = int(size[1] * .58)
        for row in range(stop):
            a[row, :] = int(142 * (1 - row / stop) ** 1.6)
        shade_alpha = Image.fromarray(a)
        shade.putalpha(shade_alpha)
        frame_image = Image.alpha_composite(frame_image, shade)

    return ImageEnhance.Contrast(frame_image.convert("RGB")).enhance(1.02)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("test", "final", "poster"), default="test")
    parser.add_argument("--target", choices=("desktop", "mobile", "both"), default="both")
    args = parser.parse_args()
    background = Image.open(SOURCE / "background-plate-v2.png").convert("RGB")
    vehicle = Image.open(SOURCE / "vehicle-cutout-white-car.png").convert("RGBA")
    vehicle = ImageEnhance.Sharpness(vehicle).enhance(1.50)
    vehicle = ImageEnhance.Contrast(vehicle).enhance(1.08)
    vehicle = ImageEnhance.Brightness(vehicle).enhance(1.15)
    total = 48 if args.mode == "test" else (1 if args.mode == "poster" else 144)
    targets = [("desktop", (960, 540))] if args.mode == "test" else [("desktop", (1280, 720)), ("mobile", (720, 1280))]
    if args.target != "both":
        targets = [target for target in targets if target[0] == args.target]
    for name, size in targets:
        out = ROOT.parent.parent / "work" / "hero-motion-v2" / f"{args.mode}-{name}-frames"
        out.mkdir(parents=True, exist_ok=True)
        for frame in range(total):
            image = make_frame(background, vehicle, size, frame, total, name == "mobile")
            image.save(out / f"frame-{frame + 1:04d}.jpg", quality=91, subsampling=0)
        print(f"Rendered {total} {name} frames to {out}")


if __name__ == "__main__":
    main()
