#!/usr/bin/env python3
"""Local static preview server for the mobile-first towing website."""
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from functools import partial
import argparse,os,re
from urllib.parse import urlsplit,parse_qs
class Handler(SimpleHTTPRequestHandler):
 def end_headers(self):
  url=urlsplit(self.path)
  if url.path.endswith(('.css','.js')) and 'v' in parse_qs(url.query):cache='public, max-age=31536000, immutable'
  elif url.path.startswith('/media/'):cache='public, max-age=86400'
  else:cache='no-cache'
  self.send_header('Cache-Control',cache)
  self.send_header('Accept-Ranges','bytes')
  super().end_headers()
 def send_head(self):
  self.byte_range=None
  path=self.translate_path(self.path)
  request=self.headers.get('Range')
  resolved=Path(path)
  if resolved.is_dir() and urlsplit(self.path).path.endswith('/'):
   resolved=resolved/'index.html'
  compressed=Path(str(resolved)+'.gz')
  accepts_gzip=any(part.strip().split(';')[0]=='gzip' and not re.search(r'q=0(?:\.0*)?(?:;|$)',part) for part in self.headers.get('Accept-Encoding','').split(','))
  if not request and accepts_gzip and resolved.is_file() and compressed.is_file() and compressed.stat().st_mtime_ns>=resolved.stat().st_mtime_ns:
   stat=resolved.stat();etag=f'"{stat.st_mtime_ns:x}-{stat.st_size:x}"'
   if self.headers.get('If-None-Match')==etag:
    self.send_response(304);self.send_header('ETag',etag);self.send_header('Vary','Accept-Encoding');self.end_headers();return None
   self.send_response(200);self.send_header('Content-Type',self.guess_type(str(resolved)))
   self.send_header('Content-Encoding','gzip');self.send_header('Vary','Accept-Encoding');self.send_header('ETag',etag)
   self.send_header('Last-Modified',self.date_time_string(stat.st_mtime));self.send_header('Content-Length',str(compressed.stat().st_size));self.end_headers();return compressed.open('rb')
  if request and os.path.isfile(path):
   size=os.path.getsize(path);match=re.fullmatch(r'bytes=(\d*)-(\d*)',request.strip())
   if not match or not any(match.groups()):return self.invalid_range(size)
   a,b=match.groups()
   if a:start=int(a);end=int(b) if b else size-1
   else:start=max(0,size-int(b));end=size-1
   end=min(end,size-1)
   if start>=size or start>end:return self.invalid_range(size)
   f=open(path,'rb');f.seek(start);self.byte_range=(start,end)
   self.send_response(206);self.send_header('Content-Type',self.guess_type(path));self.send_header('Content-Range',f'bytes {start}-{end}/{size}');self.send_header('Content-Length',str(end-start+1));self.end_headers();return f
  return super().send_head()
 def invalid_range(self,size):
  self.send_response(416);self.send_header('Content-Range',f'bytes */{size}');self.send_header('Content-Length','0');self.end_headers();return None
 def copyfile(self,source,outputfile):
  if self.byte_range:
   remaining=self.byte_range[1]-self.byte_range[0]+1
   while remaining:
    data=source.read(min(65536,remaining))
    if not data:break
    outputfile.write(data);remaining-=len(data)
  else:super().copyfile(source,outputfile)
parser=argparse.ArgumentParser();parser.add_argument('--host',default='127.0.0.1');parser.add_argument('--port',type=int,default=4173);args=parser.parse_args()
directory=str(Path(__file__).resolve().parent.parent/'dist')
server=ThreadingHTTPServer((args.host,args.port),partial(Handler,directory=directory))
print(f'Local preview: http://{args.host}:{args.port}',flush=True)
try:server.serve_forever()
except KeyboardInterrupt:server.server_close()
