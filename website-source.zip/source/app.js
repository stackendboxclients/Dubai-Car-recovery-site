'use strict';
if(['127.0.0.1','localhost'].includes(location.hostname)&&new URLSearchParams(location.search).get('qa')==='1')window.__TOWING_TEST_MODE__=true;
const business=JSON.parse(document.getElementById('business-config').textContent);
const menuButton=document.querySelector('.menu-toggle');
const menu=document.getElementById('mobile-navigation');
menuButton.addEventListener('click',()=>{const open=menuButton.getAttribute('aria-expanded')==='true';menuButton.setAttribute('aria-expanded',String(!open));menuButton.setAttribute('aria-label',open?'Open navigation':'Close navigation');menu.hidden=open;});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!menu.hidden){menu.hidden=true;menuButton.setAttribute('aria-expanded','false');menuButton.setAttribute('aria-label','Open navigation');menuButton.focus();}});
for(const a of menu.querySelectorAll('a')){const path=new URL(a.getAttribute('href'),location.origin).pathname;const current=location.pathname;if(path===current||(path==='/services/'&&current.startsWith('/services/')))a.setAttribute('aria-current','page');}
const mailIcon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 6 9 7 9-7"/></svg>';
for(const slot of document.querySelectorAll('.email-slot')){if(business.email&&/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(business.email)){const a=document.createElement('a');a.className='email-enabled';a.href='mailto:'+business.email;a.innerHTML=mailIcon+'<span>Email us</span>';slot.append(a);}else{slot.innerHTML='<span class="email-disabled" aria-label="Email contact not available">'+mailIcon+'<span>Email unavailable</span></span>';}}
if(business.email){const desc=document.querySelector('.email-description');if(desc)desc.textContent='Send an email to '+business.email+'.';}
for(const form of document.querySelectorAll('.booking-form')){
 const service=form.elements.service;const requested=new URLSearchParams(location.search).get('service');
 const clearDraft=()=>{const link=form.querySelector('.prepared-link');link.hidden=true;link.removeAttribute('href');form.querySelector('.form-status').textContent='';if(window.__TOWING_TEST_MODE__)window.__preparedWhatsAppURL=undefined;};
 form.addEventListener('input',clearDraft);form.addEventListener('change',clearDraft);
 const routeNames={'car-towing':'Car towing','flatbed-towing':'Flatbed towing','luxury-car-transport':'Luxury & sports cars','emergency-recovery':'Breakdown recovery','accident-recovery':'Accident recovery','roadside-assistance':'Roadside assistance','battery-assistance':'Battery boost assistance','tyre-assistance':'Tyre assistance','fuel-delivery':'Emergency fuel assistance','desert-recovery':'Desert & off-road recovery','motorcycle-towing':'Motorcycle transport','truck-recovery':'Commercial vehicle recovery','passing-assistance':'Vehicle passing transport assistance'};
 if(routeNames[requested])service.value=routeNames[requested];
 form.elements.timing.addEventListener('change',()=>{const scheduled=form.querySelector('.scheduled');scheduled.hidden=form.elements.timing.value!=='Scheduled pickup';form.elements.datetime.required=!scheduled.hidden;});
 const rules={name:v=>v.trim().length>=2?'':'Please enter your name.',phone:v=>/^\+?[0-9\s().-]{7,25}$/.test(v.trim())&&v.replace(/\D/g,'').length>=7?'':'Please enter a valid contact number.',service:v=>v?'':'Please choose a service.',location:v=>v.trim().length>=3?'':'Please add a pickup location or landmark.'};
 function validateField(key){const input=form.elements[key],message=rules[key](input.value);const error=form.querySelector('#'+key+'-error');error.textContent=message;input.setAttribute('aria-invalid',String(Boolean(message)));input.setAttribute('aria-describedby',error.id);return !message;}
 for(const key of Object.keys(rules)){form.elements[key].addEventListener('input',()=>{if(form.elements[key].getAttribute('aria-invalid')==='true')validateField(key);});}
 form.addEventListener('submit',e=>{e.preventDefault();clearDraft();let first=null;for(const key of Object.keys(rules)){if(!validateField(key)&&!first)first=form.elements[key];}if(first){first.focus();return;}
 if(form.elements.timing.value==='Scheduled pickup'&&(!form.elements.datetime.value||new Date(form.elements.datetime.value).getTime()<=Date.now())){form.querySelector('.form-status').textContent='Please choose a future date and time for your scheduled pickup.';form.elements.datetime.setAttribute('aria-invalid','true');form.elements.datetime.focus();return;}
 form.elements.datetime.removeAttribute('aria-invalid');
 const lines=['Hello '+business.name+', I would like to discuss assistance.','Name: '+form.elements.name.value.trim(),'Phone: '+form.elements.phone.value.trim(),'Service: '+service.value,'Pickup: '+form.elements.location.value.trim()];
 for(const key of ['vehicle','destination','timing','datetime','notes']){const value=form.elements[key].value.trim();if(value&&(key!=='datetime'||form.elements.timing.value==='Scheduled pickup'))lines.push(key.charAt(0).toUpperCase()+key.slice(1)+': '+value);}
 if(currentLocation&&form.elements.location.value.trim()==='Current location: '+currentLocation.mapsURL&&Date.now()-currentLocation.capturedAt<120000){lines.push('Live pickup map: '+currentLocation.mapsURL,'Coordinates: '+currentLocation.lat+', '+currentLocation.lng,'Device-reported accuracy: within '+currentLocation.accuracy+' metres');}
 lines.push('Please confirm suitability, availability and a quote.');
 const url='https://wa.me/'+business.whatsapp+'?text='+encodeURIComponent(lines.join('\n'));const link=form.querySelector('.prepared-link');link.href=url;link.hidden=false;
 form.querySelector('.form-status').textContent='Your enquiry is prepared. WhatsApp will open so you can review and send it. This is not yet a confirmed booking.';
 if(window.__TOWING_TEST_MODE__){window.__preparedWhatsAppURL=url;return;}
 location.assign(url);
 });
}
let currentLocation=null;
const locationButtons=[...document.querySelectorAll('.location-action')];
const locationResults=[...document.querySelectorAll('.location-result')];
function showLocation(message,kind='info',mapsURL=''){
 for(const box of locationResults){box.dataset.kind=kind;box.innerHTML='';const text=document.createElement('span');text.textContent=message;box.append(text);if(mapsURL){const link=document.createElement('a');link.href=mapsURL;link.target='_blank';link.rel='noopener';link.textContent='Check pickup pin in Google Maps';box.append(link);}}
}
function resetLocationButtons(){
 for(const button of locationButtons){button.disabled=false;button.querySelector('span').textContent='Use my current location';}
}
function useLocation(position){
 const lat=position.coords.latitude.toFixed(6),lng=position.coords.longitude.toFixed(6);
 const mapsURL='https://www.google.com/maps/search/?api=1&query='+encodeURIComponent(lat+','+lng);
 const previous=currentLocation?.mapsURL;
 currentLocation={lat,lng,mapsURL,accuracy:Math.ceil(position.coords.accuracy),capturedAt:position.timestamp};
 for(const form of document.querySelectorAll('.booking-form')){
  const input=form.elements.location;
  if(input&&(!input.value.trim()||input.value.trim()==='Current location: '+previous)){input.value='Current location: '+mapsURL;input.dispatchEvent(new Event('input',{bubbles:true}));}
 }
 for(const button of locationButtons){button.classList.add('is-ready');button.querySelector('span').textContent='Refresh my current location';}
 const captured=new Date(currentLocation.capturedAt).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit',second:'2-digit'});
 showLocation('Fresh device location found at '+captured+' (within '+currentLocation.accuracy+' m). Your exact map pin is ready to share. Check the pin before sending. A manually entered pickup is kept.','success',mapsURL);
}
function locationFailure(message){
 resetLocationButtons();showLocation(message,'error');
 const pickup=document.querySelector('.booking-form')?.elements.location.value.trim();
 const text='Hello '+business.name+', I need towing assistance. '+(pickup?'Pickup location: '+pickup:'I will share my pickup location in this chat.');
 for(const box of locationResults){const fallback=document.createElement('a');fallback.href='https://wa.me/'+business.whatsapp+'?text='+encodeURIComponent(text);fallback.textContent='Share a pickup pin or landmark on WhatsApp';box.append(fallback);}
}
function requestLocation(){
 if(!window.isSecureContext&&location.hostname!=='localhost'&&location.hostname!=='127.0.0.1'){locationFailure('Location needs HTTPS. Open the secure website or enter your pickup manually.');return;}
 if(!navigator.geolocation){locationFailure('Location is unavailable in this browser. Enter an area, landmark or Google Maps link manually.');return;}
 const previous=currentLocation?.mapsURL;
 // A location must be measured after this tap. This prevents a stored or old fix from being shared.
 const requestStartedAt=Date.now();
 currentLocation=null;
 for(const form of document.querySelectorAll('.booking-form'))if(previous&&form.elements.location.value.trim()==='Current location: '+previous){form.elements.location.value='';form.elements.location.dispatchEvent(new Event('input',{bubbles:true}));}
 for(const button of locationButtons){button.disabled=true;button.classList.remove('is-ready');button.querySelector('span').textContent='Finding a precise location…';}
 showLocation('Waiting for your phone’s location. Allow precise location if prompted. This can take up to 25 seconds.');
 let best=null,watchId=null,done=false,timer=null;
 const finish=(error)=>{
  if(done)return;done=true;
  if(watchId!==null)navigator.geolocation.clearWatch(watchId);
  if(timer!==null)clearTimeout(timer);
  resetLocationButtons();
  if(best&&best.coords.accuracy<=20){useLocation(best);return;}
  const messages={1:'Location permission was denied. Enable location for this browser and precise location on your phone, or enter a pickup manually.',2:'Your phone could not determine a reliable location. Try outdoors or share a map pin manually.',3:'A precise location was not found in time. Try again with precise location enabled, or enter a landmark or map pin.'};
  locationFailure(best?'Your device could only provide a location within '+Math.ceil(best.coords.accuracy)+' metres. It was not shared because a 20 m or better pickup pin is required. Turn on Precise Location, move outdoors if possible, then try again, or paste a Google Maps pin manually.':messages[error?.code]||'We could not get a reliable location. Enter a landmark or map pin manually.');
 };
 const accept=position=>{
  if(done)return;
  const c=position.coords;
  if(!Number.isFinite(c.latitude)||!Number.isFinite(c.longitude)||Math.abs(c.latitude)>90||Math.abs(c.longitude)>180||!Number.isFinite(c.accuracy)||c.accuracy<=0||!Number.isFinite(position.timestamp)||position.timestamp<requestStartedAt-1000||Date.now()-position.timestamp>30000)return;
  if(!best||c.accuracy<best.coords.accuracy)best=position;
  if(c.accuracy<=20)finish();
 };
 timer=setTimeout(()=>finish({code:3}),25000);
 const options={enableHighAccuracy:true,timeout:25000,maximumAge:0};
 if(navigator.geolocation.watchPosition){watchId=navigator.geolocation.watchPosition(accept,finish,options);if(done&&watchId!==null)navigator.geolocation.clearWatch(watchId);}
 else navigator.geolocation.getCurrentPosition(position=>{accept(position);if(!done)finish({code:3});},finish,options);
}
for(const button of locationButtons){button.querySelector('span').textContent='Use my current location';button.addEventListener('click',requestLocation);}

const sticky=document.querySelector('.sticky-contact');const heroActions=document.querySelector('.hero-actions');let heroActionsVisible=Boolean(heroActions);
function updateSticky(){const editing=/INPUT|TEXTAREA|SELECT/.test(document.activeElement?.tagName||'');const show=Boolean(sticky)&&!heroActionsVisible&&!editing;sticky.hidden=!show;document.body.classList.toggle('has-sticky',show);}
if(sticky&&!heroActions){updateSticky();document.addEventListener('focusin',updateSticky);document.addEventListener('focusout',()=>setTimeout(updateSticky,50));}
if(sticky&&heroActions){new IntersectionObserver(entries=>{heroActionsVisible=entries[0].isIntersecting;updateSticky();},{threshold:0}).observe(heroActions);document.addEventListener('focusin',updateSticky);document.addEventListener('focusout',()=>setTimeout(updateSticky,50));}

const heroVideo=document.querySelector('video.hero-video');
if(heroVideo){
 if(matchMedia('(max-width:699px)').matches&&heroVideo.dataset.mobilePoster)heroVideo.poster=heroVideo.dataset.mobilePoster;
 const reduced=window.matchMedia('(prefers-reduced-motion: reduce)');let visible=true,failed=false;
 const syncVideo=()=>{if(failed||reduced.matches||document.hidden||!visible){heroVideo.pause();return;}heroVideo.play().catch(()=>{});};
 heroVideo.addEventListener('error',()=>{failed=true;heroVideo.hidden=true;});
 new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;syncVideo();},{threshold:.05}).observe(document.querySelector('.hero'));
 reduced.addEventListener('change',syncVideo);document.addEventListener('visibilitychange',syncVideo);syncVideo();
}

const hero=document.querySelector('.hero');
// Hero background motion is CSS-only and does not respond to pointer or touch.

const revealItems=[...document.querySelectorAll('[data-reveal]')];
if(revealItems.length){
 const reduced=matchMedia('(prefers-reduced-motion:reduce)').matches;
 if(reduced||!('IntersectionObserver' in window)){for(const item of revealItems)item.classList.add('is-visible');}
 else{const revealObserver=new IntersectionObserver(entries=>{for(const entry of entries){if(entry.isIntersecting){entry.target.classList.add('is-visible');revealObserver.unobserve(entry.target);}}},{threshold:.14,rootMargin:'0px 0px -6%'});for(const item of revealItems)revealObserver.observe(item);}
}

const whySection=document.querySelector('.why-section');
if(whySection&&!matchMedia('(prefers-reduced-motion:reduce)').matches){
 const cards=[...whySection.querySelectorAll('.why-card')];let whyFrame=0,pointerX=0,pointerY=0,touchReset=0;
 const renderWhy=()=>{whyFrame=0;const rect=whySection.getBoundingClientRect();if(rect.bottom<0||rect.top>innerHeight)return;const travel=Math.max(1,innerHeight+rect.height);const progress=Math.max(0,Math.min(1,(innerHeight-rect.top)/travel));for(const [index,card] of cards.entries()){const direction=index%2?1:-1;const row=Math.floor(index/2)-1;card.style.setProperty('--why-scroll-x',((progress-.5)*direction*18).toFixed(2)+'px');card.style.setProperty('--why-scroll-y',((progress-.5)*row*12).toFixed(2)+'px');card.style.setProperty('--why-pointer-x',(pointerX*direction).toFixed(2)+'px');card.style.setProperty('--why-pointer-y',(pointerY*(index%3-1)*.55).toFixed(2)+'px');card.style.setProperty('--why-tilt',(pointerX*direction*.16).toFixed(2)+'deg');}}
 const scheduleWhy=()=>{if(!whyFrame)whyFrame=requestAnimationFrame(renderWhy);};
 const followWhy=event=>{const rect=whySection.getBoundingClientRect();pointerX=Math.max(-9,Math.min(9,((event.clientX-rect.left)/rect.width-.5)*18));pointerY=Math.max(-7,Math.min(7,((event.clientY-rect.top)/rect.height-.5)*14));scheduleWhy();};
 const resetWhy=()=>{pointerX=0;pointerY=0;scheduleWhy();};
 whySection.addEventListener('pointermove',followWhy);
 whySection.addEventListener('pointerdown',event=>{clearTimeout(touchReset);followWhy(event);});
 whySection.addEventListener('pointerup',event=>{if(event.pointerType==='touch')touchReset=setTimeout(resetWhy,550);});
 whySection.addEventListener('pointercancel',resetWhy);whySection.addEventListener('pointerleave',resetWhy);
 addEventListener('scroll',scheduleWhy,{passive:true});addEventListener('resize',scheduleWhy,{passive:true});renderWhy();
 const whyColorObserver=new IntersectionObserver(entries=>{for(const entry of entries)entry.target.classList.toggle('is-green',entry.isIntersecting&&entry.intersectionRatio>=.62);},{threshold:[0,.35,.62,.8,1]});
 whyColorObserver.observe(whySection);
 const retriggerCard=(card,className)=>{card.classList.remove(className);void card.offsetWidth;card.classList.add(className);setTimeout(()=>card.classList.remove(className),760);};
 for(const card of cards){
  card.addEventListener('pointerdown',event=>{if(event.pointerType==='touch'||event.pointerType==='pen')retriggerCard(card,'uiverse-active');});
  card.addEventListener('click',()=>retriggerCard(card,'uiverse-active'));
 }
 let sequenceRunning=false,sequenceTimers=[];
 const runCardSequence=()=>{if(sequenceRunning)return;sequenceRunning=true;sequenceTimers.forEach(clearTimeout);sequenceTimers=cards.map((card,index)=>setTimeout(()=>retriggerCard(card,'uiverse-auto'),index*155));sequenceTimers.push(setTimeout(()=>{sequenceRunning=false;},cards.length*155+800));};
 const whySequenceObserver=new IntersectionObserver(entries=>{for(const entry of entries){if(entry.isIntersecting)runCardSequence();else{sequenceRunning=false;sequenceTimers.forEach(clearTimeout);sequenceTimers=[];}}},{threshold:.22});
 whySequenceObserver.observe(whySection);
}

const reviewStage=document.querySelector('.customer-review-stage');
if(reviewStage){
 const reviewCards=[...reviewStage.querySelectorAll('.customer-review-card')];
 const reviewDots=[...document.querySelectorAll('.review-dots span')];
 let reviewStart=0,reviewTimer=0;
 const showReviewSet=()=>{for(const [index,card] of reviewCards.entries()){const visible=index===reviewStart;card.classList.toggle('is-review-visible',visible);reviewDots[index]?.classList.toggle('is-active',visible);}};
 const nextReviewSet=()=>{if(document.hidden||reviewStage.closest('.motion-dormant'))return;reviewStart=(reviewStart+1)%reviewCards.length;showReviewSet();};
 showReviewSet();
 if(!matchMedia('(prefers-reduced-motion:reduce)').matches)reviewTimer=setInterval(nextReviewSet,2000);
}

// Our Services cards are display-only; their CSS orbit always runs.

// Transport gallery: autoplay never pauses for hover, focus or manual interaction.
const transportViewport=document.querySelector('.transport-viewport');
if(transportViewport){
 const track=transportViewport.querySelector('.transport-track');
 // Mix the four bike scenes between existing scenes, keeping them separated.
 const bikeSlides=[...track.querySelectorAll('[data-bike="true"]')];
 const vehicleSlides=[...track.querySelectorAll('[data-bike="false"]')];
 if(bikeSlides.length&&vehicleSlides.length){
  for(let i=bikeSlides.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[bikeSlides[i],bikeSlides[j]]=[bikeSlides[j],bikeSlides[i]];}
  let gaps=[];
  for(let attempt=0;attempt<100;attempt++){
   const candidates=Array.from({length:vehicleSlides.length-1},(_,i)=>i);
   for(let i=candidates.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[candidates[i],candidates[j]]=[candidates[j],candidates[i]];}
   gaps=candidates.slice(0,bikeSlides.length).sort((a,b)=>a-b);
   if(gaps.every((gap,i)=>!i||gap-gaps[i-1]>1))break;
  }
  if(!gaps.every((gap,i)=>!i||gap-gaps[i-1]>1))gaps=[1,4,7,10];
  const mixed=[];let bikeIndex=0;
  vehicleSlides.forEach((slide,i)=>{mixed.push(slide);if(gaps.includes(i))mixed.push(bikeSlides[bikeIndex++]);});
  track.replaceChildren(...mixed);
 }
 const originals=[...track.children],count=originals.length;
 const makeClones=()=>originals.map(slide=>{const clone=slide.cloneNode(true);clone.setAttribute('aria-hidden','true');clone.querySelector('img').alt='';return clone;});
 track.prepend(...makeClones());track.append(...makeClones());
 let index=count,step=0,dragOffset=0,startX=0,startY=0,dragging=false,horizontal=false,frame=0;
 const render=(animate=true)=>{track.style.transitionDuration=animate?'700ms':'0ms';track.style.transform=`translate3d(${-index*step+dragOffset}px,0,0)`;transportViewport.dataset.slide=String(((index-count)%count+count)%count+1);};
 const measure=()=>{step=originals[0].getBoundingClientRect().width+parseFloat(getComputedStyle(track).gap);render(false);};
 const normalize=()=>{if(index>=2*count){index-=count;render(false);}else if(index<count){index+=count;render(false);}};
 track.addEventListener('transitionend',event=>{if(event.target===track&&event.propertyName==='transform')normalize();});
 const advance=()=>{if(document.hidden||transportViewport.closest('.motion-dormant'))return;normalize();index++;render(true);};
 measure();new ResizeObserver(measure).observe(transportViewport);
 setInterval(advance,2000);
 transportViewport.addEventListener('pointerdown',event=>{if(event.button!==0)return;dragging=true;horizontal=false;startX=event.clientX;startY=event.clientY;dragOffset=0;});
 transportViewport.addEventListener('pointermove',event=>{if(!dragging)return;const dx=event.clientX-startX,dy=event.clientY-startY;if(!horizontal&&Math.abs(dx)>8&&Math.abs(dx)>Math.abs(dy)){horizontal=true;transportViewport.setPointerCapture(event.pointerId);transportViewport.classList.add('is-dragging');}if(horizontal){dragOffset=dx;if(!frame)frame=requestAnimationFrame(()=>{frame=0;render(false);});}});
 const release=event=>{if(!dragging)return;dragging=false;if(horizontal){if(Math.abs(dragOffset)>step*.12)index+=dragOffset<0?1:-1;}dragOffset=0;horizontal=false;transportViewport.classList.remove('is-dragging');try{transportViewport.releasePointerCapture(event.pointerId);}catch{}render(true);};
 transportViewport.addEventListener('pointerup',release);transportViewport.addEventListener('pointercancel',release);
 transportViewport.addEventListener('pointerleave',event=>{if(dragging&&!horizontal)release(event);});
 transportViewport.addEventListener('keydown',event=>{if(event.key==='ArrowRight'||event.key==='ArrowLeft'){event.preventDefault();normalize();index+=event.key==='ArrowRight'?1:-1;render(true);}});
}

// Enlarge the selected service for reading, then restore the same orbit after inactivity.
const serviceOrbit=document.querySelector('.service-carousel');
if(serviceOrbit){
 const cards=[...serviceOrbit.querySelectorAll('.card')];
 const reader=document.createElement('dialog');reader.className='service-reader';reader.setAttribute('aria-labelledby','service-reader-title');
 reader.innerHTML='<div class="service-reader-panel"><button type="button" class="service-reader-close" aria-label="Close service details">×</button><div class="service-reader-art"></div><h2 id="service-reader-title"></h2><p class="service-reader-description"></p><div class="service-reader-controls"><button type="button" class="service-reader-previous" aria-label="Previous service">← Previous</button><span class="service-reader-count"></span><button type="button" class="service-reader-next" aria-label="Next service">Next →</button></div><p class="service-reader-hint">Swipe left or right. Rotation resumes after 6 seconds without interaction.</p></div>';
 document.body.append(reader);
 const panel=reader.querySelector('.service-reader-panel');let selected=0,timer=0,startX=0,startY=0,swiping=false;
 const schedule=()=>{clearTimeout(timer);timer=setTimeout(()=>reader.close(),6000);};
 const show=index=>{selected=(index+cards.length)%cards.length;const card=cards[selected];panel.classList.toggle('is-black',card.classList.contains('card-black'));reader.querySelector('.service-reader-art').replaceChildren(card.querySelector('.service-art').cloneNode(true));reader.querySelector('h2').textContent=card.querySelector('h3').textContent;reader.querySelector('.service-reader-description').textContent=card.querySelector('p').textContent;reader.querySelector('.service-reader-count').textContent=(selected+1)+' / '+cards.length;schedule();};
 cards.forEach((card,index)=>card.querySelector('.img').addEventListener('click',()=>{show(index);serviceOrbit.classList.add('is-reading');if(!reader.open)reader.showModal();}));
 reader.addEventListener('close',()=>{clearTimeout(timer);serviceOrbit.classList.remove('is-reading');});
 reader.querySelector('.service-reader-close').addEventListener('click',()=>reader.close());
 reader.querySelector('.service-reader-previous').addEventListener('click',()=>show(selected-1));reader.querySelector('.service-reader-next').addEventListener('click',()=>show(selected+1));
 reader.addEventListener('click',event=>{if(event.target===reader)reader.close();});
 reader.addEventListener('keydown',event=>{if(event.key==='ArrowLeft'){event.preventDefault();show(selected-1);}else if(event.key==='ArrowRight'){event.preventDefault();show(selected+1);}else schedule();});
 panel.addEventListener('pointerdown',event=>{startX=event.clientX;startY=event.clientY;swiping=true;clearTimeout(timer);});
 panel.addEventListener('pointerup',event=>{if(swiping){const dx=event.clientX-startX,dy=event.clientY-startY;if(Math.abs(dx)>45&&Math.abs(dx)>Math.abs(dy))show(selected+(dx<0?1:-1));swiping=false;}schedule();});
 panel.addEventListener('pointercancel',()=>{swiping=false;schedule();});
 panel.addEventListener('pointerleave',()=>{if(swiping){swiping=false;schedule();}});
}

// Keep the supplied scene's vehicle silhouette clear of copy and viewport margins.
if(hero){
 const image=hero.querySelector('.hero-video');
 const fitHeroVehicle=()=>{
  if(!image?.naturalWidth)return;
  const width=hero.clientWidth,height=hero.clientHeight;
  const fit=Math.min(width*.96/image.naturalWidth,height*.96/image.naturalHeight);
  const imageBottom=height*.98;
  const baseTop=imageBottom-(image.naturalHeight-1260)*fit;
  const baseBottom=imageBottom-(image.naturalHeight-1540)*fit;
  const copyBottom=hero.querySelector('.hero-vehicle-line').getBoundingClientRect().bottom-hero.getBoundingClientRect().top;
  const available=Math.max(150,height-copyBottom-64);
  const zoom=Math.max(1,Math.min(1.45,(width-64)/(540*fit),available/(280*fit)));
  const top=imageBottom-(imageBottom-baseTop)*zoom;
  const bottom=imageBottom-(imageBottom-baseBottom)*zoom;
  const minDrop=copyBottom+28-top,maxDrop=height-36-bottom;
  const drop=Math.min(maxDrop,Math.max(45,minDrop));
  hero.style.setProperty('--vehicle-zoom',zoom.toFixed(3));
  hero.style.setProperty('--vehicle-drop',drop.toFixed(1)+'px');
 };
 image.addEventListener('load',fitHeroVehicle);new ResizeObserver(fitHeroVehicle).observe(hero.querySelector('.hero-content'));addEventListener('resize',fitHeroVehicle);fitHeroVehicle();
}

// Suspend offscreen animation work without interrupting visible interaction.
if('IntersectionObserver' in window){
 const motionObserver=new IntersectionObserver(entries=>{for(const entry of entries)entry.target.classList.toggle('motion-dormant',!entry.isIntersecting);},{rootMargin:'180px 0px'});
 for(const section of document.querySelectorAll('.service-carousel-section,.why-section,.reviews-section,.transport-showcase'))motionObserver.observe(section);
}
const syncBackgroundMotion=()=>document.body.classList.toggle('is-background',document.hidden);
document.addEventListener('visibilitychange',syncBackgroundMotion);syncBackgroundMotion();

// Crossfade before the supplied clip ends; reset only the hidden player.
const backgroundPlayers=[...document.querySelectorAll('.site-motion-background')];
if(backgroundPlayers.length===2){
 const reducedMotion=matchMedia('(prefers-reduced-motion: reduce)');
 let activePlayer=0,switching=false;
 const resumeBackground=()=>{
  if(document.hidden||reducedMotion.matches){backgroundPlayers.forEach(v=>v.pause());return;}
  backgroundPlayers[activePlayer].play()?.catch(()=>{});
 };
 const swapBackground=async()=>{
  if(switching||document.hidden||reducedMotion.matches)return;
  switching=true;
  const previous=backgroundPlayers[activePlayer],next=backgroundPlayers[1-activePlayer];
  next.currentTime=0;
  try{await next.play();}catch{switching=false;previous.currentTime=0;return;}
  next.classList.add('is-active');previous.classList.remove('is-active');
  activePlayer=1-activePlayer;
  setTimeout(()=>{previous.pause();previous.currentTime=0;switching=false;},720);
 };
 backgroundPlayers.forEach((player,index)=>{
  player.addEventListener('timeupdate',()=>{
   if(index===activePlayer&&Number.isFinite(player.duration)&&player.duration-player.currentTime<=.85)swapBackground();
  });
  player.addEventListener('ended',()=>{if(index===activePlayer)swapBackground();});
 });
 document.addEventListener('visibilitychange',resumeBackground);
 reducedMotion.addEventListener?.('change',resumeBackground);
 resumeBackground();
}
