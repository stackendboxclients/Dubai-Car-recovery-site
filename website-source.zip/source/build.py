from pathlib import Path
import json,html,shutil,argparse,hashlib,re,gzip
from urllib.parse import urlsplit
root=Path(__file__).resolve().parent.parent; dist=root/'dist';dist.mkdir(exist_ok=True)
(dist/'media').mkdir(exist_ok=True)
b=json.loads((root/'source/business.json').read_text())
parser=argparse.ArgumentParser(description='Build the local preview or public deployment files.')
parser.add_argument('--production',action='store_true')
parser.add_argument('--domain',help='Public client website HTTPS origin, required for production.')
args=parser.parse_args()
public_domain=(args.domain or b.get('domain') or '').rstrip('/')
if args.production:
 parsed=urlsplit(public_domain)
 if parsed.scheme!='https' or not parsed.hostname or parsed.hostname in ['localhost','127.0.0.1'] or parsed.path or parsed.query or parsed.fragment or parsed.username:
  parser.error('Production needs a public HTTPS client domain, e.g. --domain https://your-client-domain.com')
robots_content='index,follow' if args.production else 'noindex,nofollow'
css_version=hashlib.sha256((root/'source/styles.css').read_bytes()).hexdigest()[:12]
js_version=hashlib.sha256((root/'source/app.js').read_bytes()).hexdigest()[:12]

escape=html.escape
icons={
 'arrow':'<path d="M5 12h14m-6-6 6 6-6 6"/>',
 'phone':'<path d="M5 3h4l2 5-3 2a15 15 0 0 0 6 6l2-3 5 2v4c0 2-2 3-4 2C8 19 3 14 3 6c0-2 1-3 2-3Z"/>',
 'chat':'<path d="M21 11a9 9 0 0 1-13 8l-5 2 2-5A9 9 0 1 1 21 11Z"/><path d="M8 7c0 5 4 8 8 9"/>',
 'menu':'<path d="M4 7h16M4 12h16M4 17h16"/>',
 'truck':'<path d="M2 14V8h12v10H2zm12 4V6h5l3 5v7h-2M14 11h8"/><circle cx="6" cy="18" r="2"/><circle cx="18" cy="18" r="2"/>',
 'pin':'<path d="M19 10c0 6-7 12-7 12S5 16 5 10a7 7 0 1 1 14 0Z"/><circle cx="12" cy="10" r="2"/>',
 'check':'<path d="m5 12 4 4L19 6"/>',
 'shield':'<path d="m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6Z"/><path d="m8 12 3 3 5-6"/>',
 'mail':'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 6 9 7 9-7"/>',
 'location':'<path d="M12 22s7-6 7-12a7 7 0 1 0-14 0c0 6 7 12 7 12Z"/><circle cx="12" cy="10" r="2"/>',
 'clock':'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
}
def icon(n):return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+icons[n]+'</svg>'
def call(cls='btn call',label='Call now'):return f'<a class="{cls}" href="tel:{b["phone"]}" data-contact="phone">{icon("phone")}<span>{label}</span></a>'
def wa(cls='btn whatsapp',label='WhatsApp'):return f'<a class="{cls}" href="https://wa.me/{b["whatsapp"]}" data-contact="whatsapp">{icon("chat")}<span>{label}</span></a>'
services=[('car-towing','Car towing','Collection and transport to your chosen garage, home or destination.','Vehicle transport'),('flatbed-towing','Flatbed towing','Discuss suitable flatbed collection for your vehicle and pickup location.','Vehicle transport'),('luxury-car-transport','Luxury & sports cars','Tell us your vehicle’s clearance and handling requirements before collection.','Vehicle transport'),('emergency-recovery','Breakdown recovery','Contact our team when unexpected vehicle trouble interrupts your journey.','Recovery'),('accident-recovery','Accident recovery','Arrange transport of a damaged vehicle to a suitable destination.','Recovery'),('roadside-assistance','Roadside assistance','Describe the problem so we can discuss assistance or vehicle transport.','Roadside help'),('battery-assistance','Battery boost assistance','Discuss suitable jump-start assistance if you believe the battery is discharged.','Roadside help'),('tyre-assistance','Tyre assistance','Tell us what happened and whether you have a usable spare wheel.','Roadside help'),('fuel-delivery','Emergency fuel assistance','Contact us to discuss your fuel requirement, location and vehicle.','Roadside help'),('desert-recovery','Desert & off-road recovery','Share the terrain, location and situation so recovery suitability can be assessed.','Recovery'),('motorcycle-towing','Motorcycle transport','Discuss your motorcycle and pickup access so transport suitability can be assessed.','Vehicle transport'),('truck-recovery','Commercial vehicle recovery','Vehicle size, weight and recovery needs must be assessed before arrangements.','Recovery'),('passing-assistance','Vehicle passing transport assistance','Ask about vehicle transport required for your passing-related arrangements.','Additional assistance')]

def form():
 options=''.join(f'<option value="{escape(n)}">{escape(n)}</option>' for _,n,_,_ in services)+'<option value="Are you looking for other services?">Are you looking for other services?</option>'
 return f'''<form class="booking-form" novalidate><div class="form-grid">
 <label class="field">Your name <span aria-hidden="true">*</span><input name="name" autocomplete="name" placeholder="Full name" required maxlength="100"><small class="error" id="name-error"></small></label>
 <label class="field">Your phone <span aria-hidden="true">*</span><input name="phone" autocomplete="tel" inputmode="tel" type="tel" placeholder="Your contact number" required maxlength="30"><small class="error" id="phone-error"></small></label>
 <label class="field full">What do you need? <span aria-hidden="true">*</span><select name="service" required><option value="">Choose a service</option>{options}</select><small class="error" id="service-error"></small></label>
 <label class="field full">Pickup location <span aria-hidden="true">*</span><input name="location" autocomplete="street-address" placeholder="Area, landmark or location link" required maxlength="300"><small class="error" id="location-error"></small></label>
 </div><div class="location-tools"><button class="location-action" type="button">{icon('location')}<span>Use my current location</span></button><p>Tap the button to request a fresh location. Allow precise location in your browser and phone settings. Check the map before sending; you can also enter your pickup manually.</p><div class="location-result" role="status" aria-live="polite"></div></div><details class="form-details"><summary>Add vehicle, destination or timing details (optional) <span>+</span></summary><div class="form-grid optional-fields">
 <label class="field full">Vehicle<input name="vehicle" placeholder="Make and model, if known" maxlength="120"></label>
 <label class="field full">Destination<input name="destination" placeholder="Garage, home or other destination" maxlength="300"></label>
 <label class="field full">Timing<select name="timing"><option>As soon as available</option><option>Scheduled pickup</option></select></label>
 <label class="field full scheduled" hidden>Preferred date and time<input name="datetime" type="datetime-local" aria-label="Preferred date and time"></label>
 <label class="field full">Anything else?<textarea name="notes" rows="2" placeholder="Access restrictions or a short description" maxlength="700"></textarea></label>
 </div></details>
 <p class="form-note">We’ll prepare your enquiry in WhatsApp. Review it there and tap Send. Availability, price and dispatch are confirmed by our team.</p>
 <button class="btn whatsapp full-button" type="submit">{icon('chat')}<span>Continue on WhatsApp</span>{icon('arrow')}</button>
 <div class="form-status" role="status" aria-live="polite"></div><a class="prepared-link" hidden rel="noopener" target="_blank">Open your prepared enquiry</a>
 <p class="privacy-note">By continuing, you choose to share these details with our team via WhatsApp. <a href="/privacy/">Privacy information</a>.</p></form>'''

def service_cards(items):return '<div class="service-grid">'+''.join(f'<a class="service-card" href="/services/{sid}/"><span class="service-icon">{icon("truck")}</span><h3>{escape(name)}</h3><p>{escape(desc)}</p><span class="card-link">View service {icon("arrow")}</span></a>' for sid,name,desc,_ in items)+'</div>'
def service_art(sid):
 art={
  'car-towing':'<path d="M3 16h10V9H3zM13 12h4l3 4h1v2h-2M6 18a2 2 0 1 0 0 .1M17 18a2 2 0 1 0 0 .1"/><path d="M5 8h6l2 3H3z"/>',
  'flatbed-towing':'<path d="M2 15h14V9h3l3 4v5h-2M4 18a2 2 0 1 0 0 .1M18 18a2 2 0 1 0 0 .1"/><path d="M4 13h9l-1-3H7z"/>',
  'luxury-car-transport':'<path d="M3 15h18l-2-5-4-2H9l-4 3zM6 17a2 2 0 1 0 0 .1M18 17a2 2 0 1 0 0 .1"/><path d="M9 10h7"/>',
  'emergency-recovery':'<path d="M3 16h14l-2-5H8l-3 2zM6 18a2 2 0 1 0 0 .1M15 18a2 2 0 1 0 0 .1"/><path d="M19 4v6M19 13v.1"/>',
  'accident-recovery':'<path d="m12 6 1 3 3-1-2 3 3 2-4 1 1 4-3-3-3 3 1-4-4-1 3-2-2-3 4 1z"/><path d="M2 19h6M16 19h6"/>',
  'roadside-assistance':'<path d="M3 16h12l-2-5H7l-3 2zM6 18a2 2 0 1 0 0 .1M14 18a2 2 0 1 0 0 .1"/><path d="m18 5 3 3-6 6-3 1 1-3z"/>',
  'battery-assistance':'<rect x="4" y="7" width="16" height="11" rx="2"/><path d="M8 5v2M16 5v2M8 12h4M10 10v4M15 12h3"/>',
  'tyre-assistance':'<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3"/><path d="m7 7 2 2m8-2-2 2m2 8-2-2m-8 2 2-2"/>',
  'fuel-delivery':'<path d="M5 20V5h10v15M3 20h14M7 8h6v4H7z"/><path d="m15 8 3 2v7c0 2 3 2 3 0v-5l-2-2"/>',
  'desert-recovery':'<path d="M2 18c4-5 7-5 11 0 3-4 6-4 9 0"/><path d="M5 13h12l-2-4H9l-3 2zM8 15a2 2 0 1 0 0 .1M16 15a2 2 0 1 0 0 .1"/>',
  'motorcycle-towing':'<circle cx="6" cy="17" r="3"/><circle cx="18" cy="17" r="3"/><path d="m6 17 4-7h4l4 7m-8-7 4 7H9m5-10h3"/>',
  'truck-recovery':'<path d="M2 7h12v11H2zM14 10h4l4 4v4h-2M6 20a2 2 0 1 0 0 .1M18 20a2 2 0 1 0 0 .1"/><path d="M5 11h6"/>',
  'passing-assistance':'<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M9 7h6M9 11h6"/><path d="M8 17h8l-1-3h-5z"/>'}
 return '<span class="service-art" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">'+art[sid]+'</svg></span>'
def service_carousel(items):
 colors=[(237,18,54),(13,15,19)]
 cards=''.join(f'<div class="card {"card-red" if index % 2 == 0 else "card-black"}" style="--index:{index};--color-card:{colors[index % 2][0]}, {colors[index % 2][1]}, {colors[index % 2][2]};"><button class="img" type="button" aria-label="Read about {escape(name)}">{service_art(sid)}<h3>{escape(name)}</h3><p>{escape(desc)}</p></button></div>' for index,(sid,name,desc,_) in enumerate(items))
 return f'<div class="service-carousel wrapper"><div class="inner" style="--quantity:{len(items)};">{cards}</div></div>'
def page_head(kicker,title,desc):return f'<section class="page-intro wrap"><p class="eyebrow red">{kicker}</p><h1>{title}</h1><p class="intro-copy">{desc}</p></section>'
def contact_panel():return f'<div class="contact-pair">{call()}{wa()}</div>'
def footer():return f'''<footer><div class="wrap"><a class="footer-brand" href="/" aria-label="DubaiCarRecovery.site home"><img class="site-logo footer-logo" src="/media/company-logo-footer.webp?v=circle-logo-3" width="800" height="800" loading="lazy" decoding="async" alt="Dubai Car Recovery — Car &amp; Bike Towing"><div class="footer-logo-name">Dubai Car Recovery.site</div></a><div class="footer-contact"><a href="tel:{b['phone']}">{b['phone']}</a><p>{escape(b['location'])}</p><p class="muted">{escape(b['availability'])}</p></div><nav aria-label="Footer"><a href="/services/">Services</a><a href="/about/">About</a><a href="/contact/">Contact</a><a href="/blogs/">Blogs</a><a href="/privacy/">Privacy</a><a href="/terms/">Terms</a><a href="/disclaimer/">Disclaimer</a></nav><p class="copyright">© 2026 {escape(b['name'])}</p><div class="footer-developer"><a class="developer-credit footer-credit" aria-label="Developed by StackEndBox" href="https://www.stackendbox.com/" target="_blank" rel="noopener noreferrer"><span class="credit-label">Developed by</span><img class="developer-mark" src="/media/stackendbox-mark.webp" width="406" height="481" loading="lazy" decoding="async" alt=""><img class="developer-wordmark" src="/media/stackendbox-wordmark.webp" width="1225" height="178" loading="lazy" decoding="async" alt="StackEndBox"></a></div></div></footer>'''

hero_media='''<picture class="hero-picture"><source media="(min-width:700px)" srcset="/media/hero-desktop-recovery.webp"><img class="hero-video" src="/media/hero-mobile-poster.webp" width="941" height="1672" fetchpriority="high" decoding="async" alt="" aria-hidden="true"></picture>'''
hero_service_boxes=''.join(f'<span class="hero-service-chip">{escape(name)}</span>' for _,name,_,_ in services)
why_items=[
 ('clock','Fast Response','Quick arrival across Dubai when you need help most.'),
 ('truck','Safe &amp; Secure Towing','Vehicles are secured with belts and safety care before transport.'),
 ('shield','Careful Vehicle Handling','Your car is loaded, moved, and unloaded with full caution.'),
 ('truck','Modern Recovery Trucks','Clean, reliable flatbeds and recovery vehicles for safe transport.'),
 ('phone','24/7 Reliable Service','Day or night, our team is ready to assist you.'),
 ('chat','Professional Support','Smooth service, clear communication, and dependable handling.'),
]
why_cards=''.join(f'<article class="why-card" data-reveal style="--delay:{index * 70}ms;--why-index:{index}"><span class="why-icon">{icon(icon_name)}</span><h3>{label}</h3><p>{description}</p></article>' for index,(icon_name,label,description) in enumerate(why_items))
reviews=[
 ('Robin Varghese','2 months ago','Excellent recovery service!'),
 ('Philip Johnson','a month ago','The recovery service was smooth, professional, and reasonably priced. The driver was on time, handled the car carefully, and kept me updated throughout.'),
 ('Christy Thomas','2 months ago','The whole process was smooth, quick, and professional. The driver was very helpful and handled the car with great care.'),
 ('Talal Atassi','a month ago','The motorcycle was collected from Meydan and transported safely to Arabian Ranches on a flatbed. The driver was friendly, punctual, and handled the vehicle with excellent care.'),
 ('Dusan Miloradovic','2 months ago','The service was fast and professional, and the driver was very polite. Everything was handled with care from start to finish.'),
 ('Sandeep Singh','2 months ago','The whole process was quick, easy, and stress-free. Really impressed with the service and customer care.'),
]
def initials(name):return ''.join(part[0] for part in name.split()[:2]).upper()
review_cards=''.join(f'''<article class="customer-review-card{' is-review-visible' if index == 0 else ''}" data-review-index="{index}" data-review-name="{escape(name)}" data-review-time="{escape(date)}"><div class="review-person"><img class="review-avatar" width="192" height="192" decoding="async" loading="lazy" src="/media/review-avatar-{index + 1:02d}.webp" alt="" aria-hidden="true"><div><h3>{escape(name)}</h3><p>{escape(date)}</p></div></div><div class="review-stars" aria-label="5 out of 5 stars">★★★★★</div><blockquote>“{escape(quote)}”</blockquote></article>''' for index,(name,date,quote) in enumerate(reviews))
# Supplied recovery scenes, exclusively for the new transport carousel.
recovery_scenes=[
 ('Safe & Secure Vehicle Towing','Properly loaded, secured and transported with care.','Purple coupe on a black flatbed truck beside Ain Dubai at night.'),
 ('Professional Vehicle Recovery','Reliable recovery equipment for safe transportation.','White SUV on a dark recovery truck beneath Dubai elevated roads.'),
 ('Careful Loading & Handling','Your vehicle is treated carefully from pickup to drop-off.','Orange coupe secured on a flatbed with a Dubai bridge and skyline behind.'),
 ('Accident Vehicle Recovery','Safe recovery and transportation after an accident.','Damaged silver sedan on a recovery truck near Dubai port cranes.'),
 ('Secure Flatbed Transport','Vehicles are properly positioned and secured before transport.','Damaged blue SUV secured on an orange flatbed in Dubai at night.'),
 ('Luxury Car Recovery','Extra care for premium, sports and luxury vehicles.','Green luxury sedan on a blue recovery truck near Atlantis, Dubai.'),
 ('Careful Loading & Handling','Attention to clearance, positioning and secure loading.','Yellow sports car carried on a white flatbed against the Dubai skyline.'),
 ('Luxury Car Recovery','Professional transport for your sports and premium vehicles.','Blue sports car secured on a white flatbed at Dubai Marina.'),
 ('Professional Vehicle Recovery','Purpose-built recovery equipment. Care at every step.','Grey muscle car on a red recovery truck beside Dubai Marina.'),
 ('Safe & Secure Vehicle Towing','Careful transport from your pickup to your destination.','Red luxury coupe secured on a black flatbed with Burj Khalifa behind.'),
 ('Desert & Off-Road Recovery','Recovery equipment for challenging desert situations.','White recovery truck winching an overturned dark off-road vehicle in the Dubai desert at sunset.'),
 ('Desert Vehicle Assistance','Careful recovery when your vehicle is stuck in sand.','White recovery truck assisting a white SUV stuck in desert sand with Dubai skyline in the distance.'),
 ('Secure Flatbed Transport','Careful vehicle transport after a desert recovery.','Mud-covered sedan secured on a white flatbed truck in the Dubai desert at sunset.')
]
recovery_scenes.extend([
 ('Motorcycle Transport','Your motorcycle is secured carefully for flatbed transport.','Blue sports motorcycle secured on a silver flatbed truck in Dubai.'),
 ('Sports Bike Transport','Careful loading and secure transport for your sports bike.','Red sports motorcycle on a black flatbed beside the Dubai skyline at night.'),
 ('Bike Recovery & Transport','Discuss motorcycle pickup and transport after an off-road journey.','Orange adventure motorcycle secured on a white flatbed near the Dubai desert.'),
 ('Secure Motorcycle Transport','Your bike is carefully positioned and strapped before transport.','White motorcycle secured on a recovery truck in Dubai at night.')
])
recovery_cards=''.join(f'<article class="transport-slide" data-bike="{str(i > 13).lower()}"><img src="/media/recovery/recovery-{i:02d}.webp" width="1672" height="941" alt="{escape(alt)}" loading="lazy" decoding="async" draggable="false"><div class="transport-caption"><h3>{escape(title)}</h3><p>{escape(desc)}</p></div></article>' for i,(title,desc,alt) in enumerate(recovery_scenes,1))
transport_section=f'''<section class="transport-showcase" id="safe-vehicle-transport" aria-labelledby="transport-heading"><div class="wrap transport-intro"><p class="transport-eyebrow">SAFE VEHICLE TRANSPORT</p><h2 id="transport-heading">Your Vehicle. Handled With Care.</h2><p class="transport-description">From pickup to drop-off, every vehicle is carefully loaded, securely strapped, transported with professional recovery equipment, and handled with the attention it deserves.</p><p class="transport-trust">Secure Loading <span>•</span> Proper Strapping <span>•</span> Careful Handling <span>•</span> Professional Recovery</p></div><div class="transport-viewport" role="region" aria-roledescription="carousel" aria-label="Vehicle transport gallery" tabindex="0"><div class="transport-track">{recovery_cards}</div></div></section>'''
home=f'''<section class="hero">{hero_media}<div class="hero-shade"></div><div class="hero-grain"></div><div class="hero-ambient" aria-hidden="true"></div><div class="hero-content wrap"><div class="hero-copy"><p class="hero-dubai-title">DUBAI</p><h1><span class="metal-text" data-shimmer="24/7 ">24/7 </span><span class="neon-text" data-shimmer="CAR RECOVERY">CAR RECOVERY</span><br><span class="metal-text" data-shimmer="&amp; TOWING">&amp; TOWING</span><br><span class="metal-text hero-bike-title" data-shimmer="ALSO BIKE TOWING AND TRANSPORT">ALSO BIKE TOWING AND TRANSPORT</span></h1><p class="hero-description">Towing, recovery and flatbed transport for standard, luxury and sports cars, plus bike towing, motorcycle transport, breakdown recovery and roadside assistance across Dubai.</p><div class="hero-actions"><div class="contact-pair hero-contact-trio">{call()}{wa()}<button class="btn location-share location-action hero-location" type="button">{icon('location')}<span>Share location</span></button></div><div class="location-result hero-location-result" role="status" aria-live="polite"></div><p class="hero-condition">Subject to availability and location.</p><p class="hero-vehicle-line">WE RECOVER LUXURY, STANDARD, SPORTS CARS &amp; BIKES</p></div></div></div><div class="hero-service-dock" aria-label="Our services"><p>Our Services</p><div class="hero-service-window"><div class="hero-service-box-track"><div>{hero_service_boxes}</div><div aria-hidden="true">{hero_service_boxes}</div></div></div></div></section><div class="hero-transition" aria-hidden="true"></div>
<section class="booking-section wrap" id="booking" tabindex="-1"><div class="section-title"><div><p class="eyebrow red">REQUEST ASSISTANCE</p><h2>Tell us where you are.</h2></div><span class="step-label">Quick enquiry</span></div>{form()}</section>
<section class="section soft service-carousel-section" id="our-services"><div class="wrap"><div class="section-title"><div><h2 class="service-carousel-title">Our Services</h2></div></div>{service_carousel(services)}</div></section>
{transport_section}
<section class="section why-section" id="why-choose-us"><div class="wrap"><div class="why-heading" data-reveal><p class="why-kicker"><span></span>WHY PEOPLE CHOOSE US<span></span></p><h2><span>Why People</span> <strong>Choose Us</strong></h2></div><div class="why-grid">{why_cards}</div></div></section>
<section class="section reviews-section" id="customer-reviews"><div class="wrap"><div class="reviews-heading" data-reveal><p class="eyebrow red">CUSTOMER REVIEWS</p><h2>Customer Feedback</h2><div class="feedback-rating" aria-label="4.5 out of 5 rating"><svg class="feedback-rating-stars" viewBox="0 0 450 86" role="img" aria-label="Four full gold stars and one half gold star"><defs><path id="feedback-star" d="M40 3 L52 27 L79 31 L59 50 L64 77 L40 64 L16 77 L21 50 L1 31 L28 27 Z"/><clipPath id="feedback-stars-clip"><use href="#feedback-star" x="0"/><use href="#feedback-star" x="92"/><use href="#feedback-star" x="184"/><use href="#feedback-star" x="276"/><use href="#feedback-star" x="368"/></clipPath><linearGradient id="feedback-gold" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffd549"/><stop offset="1" stop-color="#ffb311"/></linearGradient><linearGradient id="feedback-star-shine"><stop offset="0" stop-color="#fff" stop-opacity="0"/><stop offset=".5" stop-color="#fff9d9" stop-opacity=".85"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient></defs><g fill="#a6a6a6" stroke="#929292" stroke-width="2"><use href="#feedback-star"/><use href="#feedback-star" x="92"/><use href="#feedback-star" x="184"/><use href="#feedback-star" x="276"/><use href="#feedback-star" x="368"/></g><g clip-path="url(#feedback-stars-clip)"><rect class="rating-gold-fill" width="408" height="86" fill="url(#feedback-gold)"/><rect class="rating-shine" x="-110" width="110" height="86" fill="url(#feedback-star-shine)"/></g></svg><div class="feedback-rating-label">4.5 Rating</div></div><p>Reviews supplied by the business for publication. Dates are shown exactly as provided.</p></div><div class="customer-review-stage" data-review-count="{len(reviews)}">{review_cards}</div><div class="review-dots" aria-label="Review rotation">{''.join(f'<span class="{"is-active" if index == 0 else ""}"></span>' for index in range(len(reviews)))}</div><a class="btn whatsapp review-cta" href="https://wa.me/{b['whatsapp']}">{icon('chat')}<span>Share your experience</span></a></div></section>
<section class="section wrap"><p class="eyebrow red">A SIMPLE START</p><h2>From your location<br>to your destination.</h2><ol class="process-list"><li><span>01</span><div><h3>Tell us what happened</h3><p>Share your location, vehicle and the help you need.</p></div></li><li><span>02</span><div><h3>Agree the arrangements</h3><p>Our team confirms suitability, availability and your quote.</p></div></li><li><span>03</span><div><h3>Arrange assistance</h3><p>Confirm collection and the destination with the team.</p></div></li></ol></section>
<section class="section dark"><div class="wrap"><p class="eyebrow">DUBAI COVERAGE</p><h2>Local assistance.<br>One clear contact.</h2><p>Based in Al Quoz Industrial Area. Tell us your exact pickup location so we can discuss coverage and availability.</p><a class="text-link light" href="/contact/">Contact our team {icon('arrow')}</a><p class="small-note">*24/7 assistance is subject to availability and location. Arrival estimates are confirmed when you contact us.</p></div></section>
<section class="section wrap"><p class="eyebrow red">BEFORE YOU BOOK</p><h2>A few useful answers.</h2><div class="faq"><details><summary>What information should I send?</summary><p>Your name, phone, vehicle, pickup location, what happened and your preferred destination. Mention access restrictions.</p></details><details><summary>How much does towing cost?</summary><p>The team confirms a quote based on the vehicle, distance and service. No fixed price is assumed by this website.</p></details><details><summary>Can I choose the destination?</summary><p>Tell us the garage, home or other destination you prefer. Suitability and arrangements are confirmed with the team.</p></details><details><summary>Is an online enquiry a confirmed booking?</summary><p>No. WhatsApp opens with your prepared details. Send the message and wait for our team to confirm availability and arrangements.</p></details></div></section>'''

pages={'':('Car towing & recovery in Dubai',home),'book':('Request assistance',page_head('REQUEST ASSISTANCE','Let’s arrange your pickup.','Share a few details. Our team will discuss the right assistance, availability and a quote.')+'<section class="wrap booking-page">'+form()+'</section>'),'services':('Towing & recovery services',page_head('OUR SERVICES','Help for the journey ahead.','From vehicle transport to roadside enquiries, start with the service that fits your situation.')+''.join('<section class="section wrap service-group"><h2>'+g+'</h2>'+service_cards([s for s in services if s[3]==g])+'</section>' for g in ['Vehicle transport','Recovery','Roadside help','Additional assistance'])),'about':('About DubaiCarRecovery.site',page_head('ABOUT US','Your vehicle deserves care.','Towing and recovery assistance for drivers across Dubai.')+f'''<section class="wrap prose"><h2>A clear place to start.</h2><p>{escape(b['name'])} helps you discuss vehicle collection, recovery and roadside assistance. Share where your vehicle is, what happened and where it needs to go.</p><h2>Arrangements that fit your situation.</h2><p>Vehicle condition, pickup access, distance and the assistance required all matter. We ask for those details so suitability and the quote can be discussed before you arrange a job.</p><h2>Dubai, with Al Quoz as our local area.</h2><p>Contact the team to confirm your location is covered. We do not publish a fixed arrival guarantee; an estimate depends on the actual job and conditions.</p>{contact_panel()}</section>'''),'contact':('Contact the towing team',page_head('CONTACT','One call. A clearer next step.','Tell us your location and what your vehicle needs.')+f'''<section class="wrap contact-page"><div class="contact-block"><span class="service-icon">{icon('phone')}</span><h2>Call our team</h2><a class="phone-number" href="tel:{b['phone']}">{b['phone']}</a><p>For assistance, availability and a service quote.</p>{call()}</div><div class="contact-block"><span class="service-icon green">{icon('chat')}</span><h2>Start on WhatsApp</h2><p>Share your location, vehicle and pickup details. You can start a call from inside WhatsApp.</p>{wa()}</div><div class="contact-block"><span class="service-icon">{icon('pin')}</span><h2>Our local area</h2><p>{escape(b['location'])}</p><p class="muted">Contact us for exact pickup coverage. A public premises address has not been supplied.</p></div></section>''')}
policies={
'privacy':('Privacy information',[('Your enquiry','This local website does not submit booking details to a site-operated server. The form prepares a message that you choose to share with the team through WhatsApp. Opening a chat does not automatically send that message.'),('Information you choose to provide','The enquiry can include your name, telephone number, pickup location, service, vehicle details, destination, requested timing and notes. Share only the information needed to discuss your service.'),('Location permission','The website requests precise device location only after you tap a location button. If you allow it, coordinates and a Google Maps link remain in the current page and can be added to a WhatsApp draft you choose to send. The website does not begin location access on page load, store your coordinates in a site database or provide background tracking.'),('Third-party contact channels','Telephone, Google Maps and WhatsApp actions are handled by your device and those services. Those providers have their own privacy terms. Details you send or open there are outside this local site’s storage.'),('Local data and tracking','The form keeps entered details in the current page while you use it. This implementation has no analytics, advertising scripts, tracking cookies or public enquiry database. The local server may have ordinary request logs.'),('Questions and updates','Contact the team at the published telephone number. This information must be reviewed if the website later adds backend delivery, analytics or other data processing.')]),
 'terms':('Service enquiry terms',[('Requests and confirmation','This website provides information and ways to contact the team. An enquiry or WhatsApp handoff is not a confirmed booking. Availability, suitability and dispatch must be agreed directly.'),('Service suitability','Describe your vehicle, condition, access and location accurately. Equipment requirements, coverage and service limits are assessed for each request.'),('Quotes and payment','A quote depends on the vehicle, distance and work required. Agree the price and payment arrangements with the team before the service. No fixed website price is provided.'),('Timing and changes','Arrival estimates depend on the actual request and conditions. Contact the team promptly if you need to change or cancel an arrangement. Specific cancellation conditions must be agreed with the business.'),('Authorization','Only request collection of a vehicle you own or are authorized to arrange transport for. The final business details and approved service terms can be updated when provided.')]),
'disclaimer':('Website disclaimer',[('Service information','Descriptions explain advertised towing and recovery categories. Contact the team to confirm actual capability, coverage and availability for your vehicle.'),('No arrival or outcome guarantee','This website does not guarantee a fixed arrival time, service availability, price or outcome. Estimates and arrangements are confirmed directly.'),('Illustrative scene','The hero uses an original, layered photographic motion composition created for this website. It does not depict a documented customer job, the company’s actual fleet or a specific pickup location.'),('Urgent situations','If there is immediate danger, seek appropriate emergency assistance and follow instructions from the relevant authorities. A commercial enquiry form is not an emergency response service.'),('External services','Telephone, Google Maps and WhatsApp links open external device or service functionality. Their operation depends on your device and installed applications.')])}
for route,(title,sections) in policies.items():pages[route]=(title,page_head('INFORMATION',title,'Clear information for your service enquiry.')+'<section class="wrap prose">'+''.join(f'<h2>{h}</h2><p>{d}</p>' for h,d in sections)+f'<p>Contact: <a href="tel:{b["phone"]}">{b["phone"]}</a></p></section>')
for sid,name,desc,group in services:
 pages['services/'+sid]=(name,page_head(group.upper(),name,desc)+f'<section class="wrap prose"><h2>Tell us about your vehicle.</h2><p>Share your pickup location, vehicle details, current condition and preferred destination. Mention low clearance, locked wheels, damage or restricted access so the team can assess suitability.</p><p>Contact us to discuss availability and suitability. Exact service scope and the quotation are confirmed before arrangements.</p>{contact_panel()}<a class="btn secondary" href="/book/?service={sid}">Request this service {icon("arrow")}</a><a class="text-link" href="/services/">All services {icon("arrow")}</a></section>')
# Long-form articles live on their own routes, reached from the footer Blogs link.
blog_metadata=json.loads((root/'source/blogs/metadata.json').read_text())
blog_by_route={}
blog_word_counts={}
def blog_inline(text):
 pattern=r'\[([^]]+)\]\(([^)]+)\)'
 parts=[];cursor=0
 for match in re.finditer(pattern,text):
  parts.append(escape(text[cursor:match.start()]))
  label,href=match.groups()
  extra=' target="_blank" rel="noopener noreferrer"' if href.startswith('https://') else ''
  parts.append('<a href="'+escape(href,quote=True)+'"'+extra+'>'+escape(label)+'</a>')
  cursor=match.end()
 parts.append(escape(text[cursor:]))
 return ''.join(parts)
def blog_body(slug):
 text=(root/'source/blogs'/f'{slug}.md').read_text()
 content=[];toc=[];heading_count=0
 for block in text.strip().split('\n\n'):
  if block.startswith('## '):
   title=block[3:];heading_count+=1;anchor=f'section-{heading_count}'
   content.append(f'<h2 id="{anchor}">{escape(title)}</h2>')
   toc.append(f'<a href="#{anchor}">{escape(title)}</a>')
  elif block.startswith('### '):content.append('<h3>'+escape(block[4:])+'</h3>')
  else:content.append('<p>'+blog_inline(block.replace('\n',' '))+'</p>')
 plain=re.sub(r'\[([^]]+)\]\([^)]+\)',r'\1',text)
 plain=re.sub(r'^#+\s*','',plain,flags=re.M)
 blog_word_counts[slug]=len(plain.split())
 return '\n'.join(content),''.join(toc)
blog_cards=[]
for blog in blog_metadata:
 route='blogs/'+blog['slug'];blog_by_route[route]=blog
 body,toc=blog_body(blog['slug'])
 blog_cards.append(f'<a class="blog-card" href="/{route}/"><img src="{blog["image"]}" width="1672" height="941" alt="" loading="lazy" decoding="async"><div><p class="eyebrow red">PROVIDER COMPARISON · 5,000 WORDS</p><h2>{escape(blog["title"])}</h2><p>{escape(blog["summary"])}</p><span>Read the guide →</span></div></a>')
 pages[route]=(blog['title'],page_head('RECOVERY GUIDES',blog['title'],blog['summary'])+f'<div class="wrap blog-layout"><p class="blog-meta">Published 13 October 2026 · By DubaiCarRecovery.site · {blog_word_counts[blog["slug"]]:,} words</p><details class="blog-toc"><summary>On this page</summary><nav aria-label="Article contents">{toc}</nav></details><article class="blog-article" aria-label="{escape(blog["title"])}">{body}</article><aside class="blog-callout"><h2>Discuss your collection</h2><p>Tell our team your vehicle, pickup and destination. Availability, suitability and the quote are confirmed directly.</p>{contact_panel()}<a class="text-link" href="/book/">Prepare an enquiry →</a><a class="text-link" href="/blogs/">Back to all blogs →</a></aside></div>')
 pages['blogs']=('Blogs: Car Recovery and Bike Transport in Dubai',page_head('BLOGS','Practical guides for your next pickup.','Provider comparisons, useful booking questions, and clear advice for arranging vehicle transport.')+'<section class="wrap blog-index"><div class="blog-grid">'+''.join(blog_cards)+'</div></section>')
(root/'verification/blog-word-counts.json').write_text(json.dumps(blog_word_counts,indent=2)+'\n')

header=f'''<a class="skip-link" href="#main">Skip to content</a><header class="site-header"><div class="wrap header-inner"><div class="brand-credit-group"><a class="brand" href="/" aria-label="{escape(b['name'])} home"><img class="site-logo" src="/media/company-logo-header.webp?v=circle-logo-3" width="320" height="320" alt=""><span class="brand-name company-wordmark"><strong class="wordmark-dubai">DUBAI</strong><strong class="wordmark-service"><span>CAR</span> <em>RECOVERY</em></strong><small>CAR &amp; BIKE TOWING</small><span class="wordmark-domain">DubaiCarRecovery.site</span></span></a></div><nav class="desktop-navigation" aria-label="Main navigation">{''.join(f'<a href="/{r + chr(47) if r else chr(32).strip()}">{n}</a>' for r,n in [('services','Services'),('about','About'),('book','Book assistance'),('contact','Contact')])}</nav><div class="header-actions">{call('header-call','Call now')}{wa('header-whatsapp','WhatsApp')}</div><a class="header-phone-number" href="tel:{b["phone"]}" aria-label="Call {b["phone"]}"><span>Contact number</span><strong>{b["phone"]}</strong></a><div class="header-controls"><a class="developer-credit header-credit" aria-label="Developed by StackEndBox" href="https://www.stackendbox.com/" target="_blank" rel="noopener noreferrer"><span class="credit-label" data-credit="Developed by">Developed by</span><span class="developer-brand-lockup"><img class="developer-mark" src="/media/stackendbox-mark.webp" width="406" height="481" alt=""><img class="developer-wordmark" src="/media/stackendbox-wordmark.webp" width="1225" height="178" alt="StackEndBox"></span></a><button class="menu-toggle" type="button" aria-label="Open navigation" aria-expanded="false" aria-controls="mobile-navigation">{icon('menu')}</button></div></div><nav id="mobile-navigation" class="mobile-navigation" aria-label="Mobile navigation" hidden><div class="wrap">{''.join(f'<a href="/{r + chr(47) if r else chr(32).strip()}">{n}</a>' for r,n in [('','Home'),('services','Services'),('about','About'),('book','Book assistance'),('contact','Contact')])}</div></nav></header>'''
for route,(title,content) in pages.items():
 folder=dist/route;folder.mkdir(parents=True,exist_ok=True)
 active=route.split('/')[0] or 'home'
 canonical=public_domain+('/'+route+'/' if route else '/')
 seo_titles={'':'Car Recovery Dubai | 24/7 Car & Bike Towing','services':'Car Towing & Recovery Services in Dubai','about':'About Dubai Car Recovery | Car & Bike Towing','contact':'Contact Dubai Car Recovery | Al Quoz, Dubai','book':'Request Car Recovery or Bike Transport in Dubai'}
 seo_descriptions={'':'Car recovery, flatbed towing and motorcycle transport in Dubai. Based in Al Quoz. Call +971552031145 to confirm 24/7 availability and a pickup quote.','services':'Explore car recovery, flatbed towing, motorcycle transport and roadside assistance in Dubai. Discuss your vehicle, pickup access and destination with our team.','about':'DubaiCarRecovery.site offers car and bike towing enquiries in Dubai from Al Quoz Industrial Area. Learn how collection, suitability and quotes are confirmed.','contact':'Contact DubaiCarRecovery.site on +971552031145 for car recovery, bike towing and transport in Dubai. Share your location and vehicle for an availability check.','book':'Prepare a WhatsApp enquiry for car towing, flatbed recovery or motorcycle transport in Dubai. Send your pickup details and receive team confirmation.'}
 if route in seo_titles:title=seo_titles[route]
 service=next((item for item in services if route=='services/'+item[0]),None)
 if service:
  title=service[1]+' in Dubai'
  description=service[2]+' Contact DubaiCarRecovery.site in Al Quoz for availability and a quote.'
 else:description=blog_by_route.get(route,{}).get('summary',seo_descriptions.get(route,title+' from DubaiCarRecovery.site. Contact +971552031145 for questions about our Dubai car and bike transport enquiries.'))
 structured_data=''
 if args.production:
  business_id=public_domain+'/#business'
  website_id=public_domain+'/#website'
  logo=public_domain+'/media/company-logo-footer.webp?v=circle-logo-3'
  business={'@type':'LocalBusiness','@id':business_id,'name':b['name'],'alternateName':'Dubai Car Recovery','url':public_domain+'/','telephone':b['phone'],'logo':logo,'image':logo,'description':seo_descriptions[''],'address':{'@type':'PostalAddress','streetAddress':'Al Quoz Industrial Area','addressLocality':'Dubai','addressCountry':'AE'},'areaServed':{'@type':'City','name':'Dubai'},'hasOfferCatalog':{'@type':'OfferCatalog','name':'Car recovery and bike transport services','itemListElement':[{'@type':'Offer','itemOffered':{'@type':'Service','name':name,'url':public_domain+'/services/'+sid+'/'}} for sid,name,_,_ in services]}}
  # Availability is conditional; omit exact hours, prices, ratings and coordinates until verified.
  graph=[business,{'@type':'WebSite','@id':website_id,'name':b['name'],'alternateName':'Dubai Car Recovery','url':public_domain+'/','publisher':{'@id':business_id},'inLanguage':'en'}]
  graph.append({'@type':'WebPage','@id':canonical+'#webpage','url':canonical,'name':title,'description':description,'isPartOf':{'@id':website_id},'about':{'@id':business_id},'inLanguage':'en'})
  if route:
   crumbs=[{'@type':'ListItem','position':1,'name':'Home','item':public_domain+'/'}]
   if '/' in route:
    parent=route.split('/')[0]
    crumbs.append({'@type':'ListItem','position':2,'name':parent.title(),'item':public_domain+'/'+parent+'/'})
   crumbs.append({'@type':'ListItem','position':len(crumbs)+1,'name':title,'item':canonical})
   graph.append({'@type':'BreadcrumbList','@id':canonical+'#breadcrumbs','itemListElement':crumbs})
  if service:graph.append({'@type':'Service','@id':canonical+'#service','name':title,'serviceType':service[1],'description':description,'url':canonical,'provider':{'@id':business_id},'areaServed':{'@type':'City','name':'Dubai'}})
  if route in blog_by_route:
   blog=blog_by_route[route]
   graph.append({'@type':'BlogPosting','@id':canonical+'#article','headline':title,'description':description,'datePublished':'2026-10-13','author':{'@id':business_id},'publisher':{'@id':business_id},'image':public_domain+blog['image'],'mainEntityOfPage':{'@id':canonical+'#webpage'},'wordCount':blog_word_counts[blog['slug']],'inLanguage':'en'})
  structured_data='<script type="application/ld+json">'+json.dumps({'@context':'https://schema.org','@graph':graph}).replace('<','\\u003c')+'</script>'
 social_tags=f'<meta property="og:type" content="{"article" if route in blog_by_route else "website"}"><meta property="og:site_name" content="{escape(b["name"],quote=True)}"><meta property="og:title" content="{escape(title,quote=True)}"><meta property="og:description" content="{escape(description,quote=True)}"><meta property="og:url" content="{escape(canonical,quote=True)}"><meta property="og:image" content="{public_domain}/media/company-logo-footer.webp?v=circle-logo-3"><meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="{escape(title,quote=True)}"><meta name="twitter:description" content="{escape(description,quote=True)}"><meta name="twitter:image" content="{public_domain}/media/company-logo-footer.webp?v=circle-logo-3">' if args.production else ''
 canonical_tag=f'<link rel="canonical" href="{escape(canonical)}">' if args.production else ''
 doc=f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#151e2e"><meta name="color-scheme" content="dark only"><meta name="description" content="{escape(description,quote=True)}"><meta name="robots" content="{robots_content}">{canonical_tag}{social_tags}{structured_data}<title>{escape(title)} | {escape(b['name'])}</title><link rel="icon" href="/favicon.ico?v=circle-logo-3" sizes="any"><link rel="icon" href="/favicon-32.png?v=circle-logo-3" type="image/png" sizes="32x32"><link rel="icon" href="/favicon.png?v=circle-logo-3" type="image/png" sizes="64x64"><link rel="apple-touch-icon" href="/apple-touch-icon.png?v=circle-logo-3" sizes="180x180"><link rel="manifest" href="/site.webmanifest?v=circle-logo-3"><link rel="stylesheet" href="/styles.css?v={css_version}"><script defer src="/app.js?v={js_version}"></script></head><body data-page="{active}">{header}<main id="main">{content}</main>{footer()}<div class="sticky-contact" hidden>{call()}{wa()}<a class="btn sticky-book" href="/book/">Book</a></div><script type="application/json" id="business-config">{json.dumps(b)}</script></body></html>'''
 (folder/'index.html').write_text(doc)
for icon_asset in ['favicon.png','favicon-32.png','favicon.ico','apple-touch-icon.png','app-icon-192.png','app-icon-512.png','site.webmanifest']:
 shutil.copyfile(root/'source/assets'/icon_asset,dist/icon_asset)
for logo_asset in ['company-logo-header.webp','company-logo-footer.webp','stackendbox-mark.webp','stackendbox-wordmark.webp']:
 shutil.copyfile(root/'source/assets'/logo_asset,dist/'media'/logo_asset)
for retired_logo in [dist/'favicon.svg',dist/'media/logo.svg']:
 if retired_logo.exists():retired_logo.unlink()
if args.production:
 (dist/'robots.txt').write_text('User-agent: *\nAllow: /\nSitemap: '+public_domain+'/sitemap.xml\n')
 urls=''.join('<url><loc>'+escape(public_domain+('/'+route+'/' if route else '/'))+'</loc></url>' for route in pages)
 (dist/'sitemap.xml').write_text('<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'+urls+'</urlset>')
else:
 (dist/'robots.txt').write_text('User-agent: *\nDisallow: /\n')
 (dist/'sitemap.xml').unlink(missing_ok=True)
print('Built',len(pages),'distinct page routes')

for asset in ["styles.css","app.js"]:
 shutil.copyfile(root/"source"/asset,dist/asset)
for asset in ["hero-desktop-poster.webp","hero-desktop-recovery.webp","hero-mobile-poster.webp"]:
 source=root/"source/assets"/asset
 target=dist/"media"/asset
 if source.exists():shutil.copyfile(source,target)
 elif target.exists():target.unlink()
for index in range(1,7):
 asset=f"review-avatar-{index:02d}.webp"
 source=root/"source/assets"/asset
 target=dist/"media"/asset
 if source.exists():shutil.copyfile(source,target)
for retired in ["hero-desktop.webm","hero-mobile.webm","hero-desktop.mp4","hero-mobile.mp4"]:
 target=dist/"media"/retired
 if target.exists():target.unlink()

shutil.copytree(root/"source/assets/recovery",dist/"media/recovery",dirs_exist_ok=True)

# Precompressed text files are served by the preview and usable on compatible hosts.
for text_file in [*dist.rglob('*.html'),dist/'styles.css',dist/'app.js']:
 Path(str(text_file)+'.gz').write_bytes(gzip.compress(text_file.read_bytes(),compresslevel=9,mtime=0))

for retired_brand in ['stackendbox-mark.png','stackendbox-wordmark.png']:
 (dist/'media'/retired_brand).unlink(missing_ok=True)
